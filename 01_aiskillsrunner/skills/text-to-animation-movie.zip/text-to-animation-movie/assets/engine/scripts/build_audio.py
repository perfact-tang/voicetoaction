#!/usr/bin/env python3
"""
Builds the narration pipeline for a hand-drawn explainer video.

The script (video settings + scenes + narration lines) lives in a JSON file, so
the same pipeline drives any number of videos:

    scripts/script.json
      -> public/<audioTrack>          one continuous narration track
      -> src/data/timing.ts           scene/line frame timings (runtime truth)
      -> src/data/videoConfig.ts      fps / size / output name (runtime truth)
      -> out/<id>.lrc                 timestamped subtitles
      -> out/<id>-cue-sheet.md        human readable storyboard timeline
      -> out/<id>-timing.json         full diagnostics (onsets, durations)

Steps
  1. Render each **scene** to speech as one continuous take (its lines joined
     with internal `。` turned into `，`) with whatever TTS is available:
     **edge-tts first** (Microsoft's online voices — stable prosody, natural
     Chinese; needs network), then local **MeloTTS** as the offline fallback,
     then macOS `say`, then espeak-ng/espeak. If nothing works, or `--no-audio`
     is given, silent clips of the right length are generated instead so the
     video still runs as subtitles-only.
     Per-line synthesis made every subtitle line restart the voice and left a
     0.4–0.5s hole between lines; scene-level takes remove that choppiness.
  2. Trim each take's lead/tail padding and concatenate the scenes with one
     short breath (260ms) at each visual cut. That is the only hard pause.
  3. Put each subtitle line back inside its take: multi-line scenes measure the
     individual line durations (and use any real pause), then snap the whole
     timeline to the frame grid once — never accumulated — so subtitle times
     cannot drift away from the voice.
  4. Write the TypeScript the composition imports, plus the .lrc and cue sheet.

Usage:
  python3 scripts/build_audio.py                    # uses scripts/script.json
  python3 scripts/build_audio.py --script other.json
  python3 scripts/build_audio.py --dry-run          # pacing check, no synthesis
  python3 scripts/build_audio.py --no-audio         # force subtitles-only
  python3 scripts/build_audio.py --tts edge         # force edge-tts (default)
  python3 scripts/build_audio.py --tts melo         # force the local MeloTTS
  python3 scripts/build_audio.py --tts espeak-ng    # force espeak

Both neural backends are auto-detected: any interpreter that can
`import edge_tts` / `import melo` counts (see find_tts_python). Install them with
scripts/install-melotts.sh (no sudo needed).
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import re
import shutil
import subprocess
import sys
from pathlib import Path

PROJECT = Path(__file__).resolve().parent.parent
PUBLIC = PROJECT / "public"
OUT = PROJECT / "out"

CHARS_PER_SECOND = 4.2      # measured MeloTTS rate in Han characters (incl. breaths)
SCENE_PAUSE_MS = 260        # breath between scenes (the only hard pause in the track)
FINAL_TAIL_MS = 900         # silence appended to the end of the track
SCENE_LEAD_FRAMES = 10      # scene starts shortly before its line is spoken
SILENCE_NOISE_DB = -45      # silencedetect threshold for trimming / line boundaries
SILENCE_MIN_S = 0.10

SCENE_MAX_SECONDS = 18.0    # guard rail against runaway scenes
TOTAL_MAX_SECONDS = 240.0   # guard rail against a runaway cut

RATE = 24000                # sample rate for generated audio
MAX_CLIP_SECONDS = 20.0     # silent fallback clips are capped at this

# espeak-ng is asked for these languages, in order, until one works.
ESPEAK_VOICE_CANDIDATES = ["cmn", "zh", "zh-cn"]

# MeloTTS: local neural TTS. It cannot be imported by this script's own
# interpreter (a bare system python3 with no third-party packages), so it is
# driven as a subprocess through scripts/melo_tts.py with whichever interpreter
# on this machine can `import melo`.
MELO_WORKER = Path(__file__).resolve().parent / "melo_tts.py"
# MeloTTS 全部参数都能用 MELOTTS_* 环境变量覆盖；下面是默认值。
MELO_DEFAULTS: dict = {
    "speed": 0.9,          # 比原生的 1.0 稍慢，叙述更稳，也不容易赶字幕
    # speaker 0 实测会在多行上合成出「长度正确但几乎全 0」的静音（见 melo_tts.py 说明）；
    # 改成 1 之后同样的脚本 31/31 行都有声。想换音色用 scripts/melo_audition.py 试听。
    "speaker": 1,
    "fallback_speakers": "2,3,4,5,6",  # 主音色静音时依次换这些
    "attempts": 2,         # 每个音色试几次（换种子，防偶发）
    "sdp_ratio": 0.2,      # 越低越平（0 = 只走确定性时长预测，最稳、最「念稿」）
    "noise_scale": 0.6,    # 越低语调起伏越小
    "noise_scale_w": 0.8,
    "gap_s": 0.08,         # 逗号/句号切点处额外插的停顿（每段还会留 30/60ms 余量）
    "seed": 1234,
    # 只去掉分号；逗号保留，让 MeloTTS 在逗号处切句、由 gap_s=0.14 接回来。
    # 这样字幕行边界就是一条真实的短停顿，比按字数硬切准得多。
    "strip_punct": "；;",
}
MELO_ENV_PREFIX = "MELOTTS_"

# edge-tts：微软 Edge 的在线 TTS，**默认后端**。韵律稳定、中文音色自然，
# 而且没有模型加载，逐条合成很快。代价是合成时必须联网。
EDGE_WORKER = Path(__file__).resolve().parent / "edge_tts_worker.py"
EDGE_DEFAULTS: dict = {
    "rate": "+0%",      # 语速，如 "+10%"
    "pitch": "+0Hz",    # 音高，如 "-2Hz"
    "volume": "+0%",    # 音量（后面还有统一响度归一化，一般不用动）
    "retries": 3,       # 网络抖动时的重试次数
}
EDGE_ENV_PREFIX = "EDGE_TTS_"
# script.json 的 voice 没指定 edge 音色时，按语言取这些默认音色。
EDGE_VOICE_BY_LANGUAGE = {
    "ZH": "zh-CN-YunyangNeural",   # 男声·新闻播报，平稳——讲解类旁白用这个
    "ZH_MIX_EN": "zh-CN-YunyangNeural",
    "EN": "en-US-GuyNeural",
    "JP": "ja-JP-KeitaNeural",
    "KR": "ko-KR-InJoonNeural",
    "ES": "es-ES-AlvaroNeural",
    "FR": "fr-FR-HenriNeural",
}


# --------------------------------------------------------------------------
# Script file
# --------------------------------------------------------------------------


class Script:
    def __init__(self, path: Path) -> None:
        raw = json.loads(path.read_text(encoding="utf-8"))
        self.path = path
        self.id: str = raw["id"]
        self.title: str = raw.get("title", self.id)
        self.fps: int = int(raw.get("fps", 30))
        self.width: int = int(raw.get("width", 1080))
        self.height: int = int(raw.get("height", 1920))
        self.audio_track: str = raw.get("audioTrack", "narration.wav")
        self.out_file: str = raw.get("outFile", "out/movie.mp4")
        self.style: str = raw.get("style", "whiteboard")
        self.voice: str = raw.get("voice", "auto")
        self.rate: int = int(raw.get("rate", 180))
        self.scenes: list[dict] = raw["scenes"]

        self.timing_ts: Path = PROJECT / raw.get("timingTs", "src/data/timing.ts")
        self.config_ts: Path = PROJECT / raw.get("configTs", "src/data/videoConfig.ts")
        self.lrc: Path = OUT / raw.get("lrc", f"{self.id}.lrc")
        self.cue_sheet: Path = OUT / raw.get("cueSheet", f"{self.id}-cue-sheet.md")

        ids = [l[0] for s in self.scenes for l in s["lines"]]
        if len(ids) != len(set(ids)):
            raise ValueError("duplicate line ids in script")
        self.flat = [
            (s["id"], s["visual"], l[0], l[1]) for s in self.scenes for l in s["lines"]
        ]


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------


def run(cmd: list[str]) -> subprocess.CompletedProcess:
    return subprocess.run(cmd, capture_output=True, text=True, check=False)


def probe_duration_ms(path: Path) -> float:
    res = run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "csv=p=0", str(path)]
    )
    if res.returncode != 0:
        raise RuntimeError(f"ffprobe failed for {path}: {res.stderr}")
    return float(res.stdout.strip()) * 1000.0


def silence_segments(path: Path) -> list[tuple[float, float]]:
    """Silent stretches of `path` as (start_ms, end_ms), from silencedetect."""
    res = run(
        ["ffmpeg", "-hide_banner", "-nostats", "-i", str(path),
         "-af", f"silencedetect=noise={SILENCE_NOISE_DB}dB:d={SILENCE_MIN_S}",
         "-f", "null", "-"]
    )
    starts = [float(m) * 1000 for m in re.findall(r"silence_start: ([\d.]+)", res.stderr)]
    ends = [float(m) * 1000 for m in re.findall(r"silence_end: ([\d.]+)", res.stderr)]
    return list(zip(starts, ends))


def han_len(text: str) -> int:
    """Rough 'how long does this take to say' weight."""
    return len(re.findall(r"[\u4e00-\u9fff]", text)) + len(
        re.findall(r"[A-Za-z0-9]+", text)
    )


# --------------------------------------------------------------------------
# Text to speech
# --------------------------------------------------------------------------


_tts_python_cache: dict[str, str | None] = {}


def _tts_python_candidates() -> list[str]:
    """可能装了 TTS 依赖（melo / edge_tts）的解释器，最具体的排前面。"""
    home = Path.home()
    raw = [
        os.environ.get("AISKILLS_TTS_PYTHON"),
        os.environ.get("MELOTTS_PYTHON"),
        os.environ.get("AISKILLS_MELOTTS_PYTHON"),
        sys.executable,
        shutil.which("python3"),
        shutil.which("python"),
        str(home / "melotts-venv" / "bin" / "python"),
        str(home / ".local" / "share" / "melotts" / "venv" / "bin" / "python"),
        str(home / ".venvs" / "melotts" / "bin" / "python"),
        str(home / "melotts" / ".venv" / "bin" / "python"),
    ]
    seen: set[str] = set()
    ordered: list[str] = []
    for item in raw:
        if not item:
            continue
        candidate = str(item)
        if candidate in seen:
            continue
        seen.add(candidate)
        ordered.append(candidate)
    return ordered


def find_tts_python(module: str) -> str | None:
    """能 `import <module>` 的解释器路径；找不到返回 None（按模块缓存）。

    判定标准是「真的能 import」，不是「目录存在」，所以候选列表里写错路径没有副作用。
    """
    if module not in _tts_python_cache:
        found: str | None = None
        for candidate in _tts_python_candidates():
            if not (os.path.isfile(candidate) and os.access(candidate, os.X_OK)):
                continue
            if run([candidate, "-c", f"import {module}"]).returncode == 0:
                found = candidate
                break
        _tts_python_cache[module] = found
    return _tts_python_cache[module]


def find_melo_python() -> str | None:
    """能 `import melo` 的解释器，没有则 None。"""
    return find_tts_python("melo")


def find_edge_python() -> str | None:
    """能 `import edge_tts` 的解释器，没有则 None。"""
    return find_tts_python("edge_tts")


def _melo_language(voice: str) -> str:
    """script.json 的 voice 顺便兼职 MeloTTS 的语言名（默认中文）。

    MeloTTS 支持 ZH / ZH_MIX_EN / EN / JP / KR / ES / FR；这里认不出来的值一律
    回落到 ZH，因为本 skill 的台词默认就是中文。
    """
    table = {
        "": "ZH",
        "auto": "ZH",
        "default": "ZH",
        "zh": "ZH",
        "cn": "ZH",
        "zh-cn": "ZH",
        "chinese": "ZH",
        "中文": "ZH",
        "zh_mix_en": "ZH_MIX_EN",
        "zh-mix-en": "ZH_MIX_EN",
        "mix": "ZH_MIX_EN",
        "en": "EN",
        "english": "EN",
        "jp": "JP",
        "ja": "JP",
        "japanese": "JP",
        "kr": "KR",
        "ko": "KR",
        "korean": "KR",
        "es": "ES",
        "spanish": "ES",
        "fr": "FR",
        "french": "FR",
    }
    return table.get(str(voice or "").strip().lower(), "ZH")


def _melo_settings() -> dict:
    """MeloTTS 参数 = MELO_DEFAULTS + MELOTTS_* 环境变量覆盖。

    例：MELOTTS_SPEAKER=7 MELOTTS_SPEED=1.1 MELOTTS_SDP_RATIO=0.1
    想关掉「去掉行内标点」：MELOTTS_STRIP_PUNCT=（设成空值）。
    """
    settings = dict(MELO_DEFAULTS)
    for key, default in MELO_DEFAULTS.items():
        raw = os.environ.get(f"{MELO_ENV_PREFIX}{key.upper()}")
        if raw is None:
            continue
        try:
            if isinstance(default, bool):
                settings[key] = raw.strip().lower() in ("1", "true", "yes", "on")
            elif isinstance(default, int):
                settings[key] = int(float(raw))
            elif isinstance(default, float):
                settings[key] = float(raw)
            else:
                settings[key] = raw
        except ValueError:
            print(
                f"warning: {MELO_ENV_PREFIX}{key.upper()}={raw!r} 解析失败，用默认值 {default!r}",
                file=sys.stderr,
            )
    settings["speed"] = max(0.5, min(2.0, float(settings["speed"])))
    return settings


def _edge_settings() -> dict:
    """edge-tts 参数 = EDGE_DEFAULTS + EDGE_TTS_* 环境变量覆盖。

    注意 rate/pitch/volume 是字符串（形如 "+10%"、"-2Hz"），不要按数字解析；
    想换音色也可以直接用 EDGE_TTS_VOICE=zh-CN-XiaoxiaoNeural。
    """
    settings = dict(EDGE_DEFAULTS)
    for key, default in EDGE_DEFAULTS.items():
        raw = os.environ.get(f"{EDGE_ENV_PREFIX}{key.upper()}")
        if raw is None:
            continue
        try:
            if isinstance(default, bool):
                settings[key] = raw.strip().lower() in ("1", "true", "yes", "on")
            elif isinstance(default, int):
                settings[key] = int(float(raw))
            elif isinstance(default, float):
                settings[key] = float(raw)
            else:
                settings[key] = raw
        except ValueError:
            print(
                f"warning: {EDGE_ENV_PREFIX}{key.upper()}={raw!r} 解析失败，用默认值 {default!r}",
                file=sys.stderr,
            )
    return settings


def _edge_voice(voice: str) -> str:
    """决定用哪个 edge 音色。

    优先级：$EDGE_TTS_VOICE > script.json 里直接写的 edge 音色名
    （形如 `zh-CN-YunyangNeural`）> 按语言取的默认音色（中文 = 云扬，男声·新闻播报）。
    """
    explicit = os.environ.get("EDGE_TTS_VOICE")
    if explicit:
        return explicit
    value = str(voice or "").strip()
    if value.endswith("Neural") and "-" in value:
        return value
    return EDGE_VOICE_BY_LANGUAGE.get(_melo_language(value), EDGE_VOICE_BY_LANGUAGE["ZH"])


def _tts_candidates(preferred: str) -> list[str]:
    """TTS backends to try, best first, filtered to what is installed."""
    have = {n: shutil.which(n) for n in ("say", "espeak-ng", "espeak")}
    # edge-tts 音色最稳（默认选择）；没网/没装时回退到本地 MeloTTS；再不行才 espeak。
    have["edge"] = find_edge_python() is not None
    have["melo"] = find_melo_python() is not None
    if preferred and preferred != "auto":
        aliases = {
            "macos": "say",
            "espeakng": "espeak-ng",
            "melotts": "melo",
            "edgetts": "edge",
            "edge-tts": "edge",
        }
        order = [aliases.get(preferred, preferred)]
    elif platform.system() == "Darwin" and have["say"]:
        order = ["edge", "melo", "say", "espeak-ng", "espeak"]
    else:
        order = ["edge", "melo", "espeak-ng", "espeak", "say"]
    return [n for n in order if have.get(n)]


class Tts:
    """Wraps whichever speech engine exists on this machine.

    Subclasses implement `synthesize` (produce one raw audio file) and may
    override `intermediate_path` / `prepare`. The shared `render` then runs the
    same ffmpeg normalisation for every backend, so the assembled track sounds
    consistent no matter which engine produced the clips.
    """

    def __init__(self, backend: str, espeak_voice: str | None = None) -> None:
        self.backend = backend
        self.espeak_voice = espeak_voice

    @property
    def name(self) -> str:
        if self.backend in ("espeak-ng", "espeak") and self.espeak_voice:
            return f"{self.backend} ({self.espeak_voice})"
        return self.backend

    def prepare(self, items: list[tuple[str, str]], work: Path, voice: str, rate: int) -> None:
        """Optional batch pre-pass; `items` is [(unit_id, text), ...].

        A unit is one scene (its subtitle lines already joined). Backends that
        synthesise one item at a time (say, espeak) leave this alone. MeloTTS /
        edge-tts override it so the model is loaded once and all scenes are
        synthesised in one worker run.
        """

    def intermediate_path(self, out_wav: Path) -> Path:
        """`synthesize` 写这里，之后由 `render` 统一转码成 out_wav。

        必须和 out_wav 是**不同**文件：ffmpeg 8（Ubuntu 26.04 升级后）会直接拒绝
        「Output ... same as Input」，旧版 ffmpeg 容忍同文件。espeak 原来写的就是
        out_wav 本身，升级后一回退到 espeak 就崩，所以这里统一改成独立中间文件。
        """
        return out_wav.with_name(f"{out_wav.stem}.raw.wav")

    def synthesize(self, text: str, intermediate: Path, voice: str, rate: int) -> None:
        raise NotImplementedError

    def render(self, text: str, out_wav: Path, voice: str, rate: int) -> None:
        """Synthesise `text` into `out_wav` (mono pcm_s16le)."""
        intermediate = self.intermediate_path(out_wav)
        self.synthesize(text, intermediate, voice, rate)

        res = run([
            "ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", str(intermediate),
            "-af", "highpass=f=90", "-ar", str(RATE), "-ac", "1",
            "-c:a", "pcm_s16le", str(out_wav),
        ])
        if res.returncode != 0:
            raise RuntimeError(f"ffmpeg failed converting {intermediate}: {res.stderr.strip()}")
        if intermediate != out_wav:
            intermediate.unlink(missing_ok=True)


class SayTts(Tts):
    """macOS `say`."""

    def __init__(self) -> None:
        super().__init__("say")

    def intermediate_path(self, out_wav: Path) -> Path:
        # say 输出 aiff，本来就和 out_wav 不同名，保持原样
        return out_wav.with_suffix(".aiff")

    def synthesize(self, text: str, intermediate: Path, voice: str, rate: int) -> None:
        v = "Tingting" if voice in ("", "auto", "default") else voice
        res = run(["say", "-v", v, "-r", str(rate), "-o", str(intermediate), text])
        if res.returncode != 0:
            raise RuntimeError(f"say failed: {res.stderr.strip()}")


class EspeakTts(Tts):
    """espeak-ng / espeak."""

    def __init__(self, backend: str, espeak_voice: str) -> None:
        super().__init__(backend, espeak_voice)

    def synthesize(self, text: str, intermediate: Path, voice: str, rate: int) -> None:
        # espeak takes words per minute; clamp into its useful range.
        wpm = max(120, min(280, int(rate)))
        res = run([
            self.backend, "-v", self.espeak_voice or "cmn", "-s", str(wpm),
            "-p", "48", "-a", "170", "-w", str(intermediate), text,
        ])
        if res.returncode != 0:
            raise RuntimeError(f"{self.backend} failed: {res.stderr.strip()}")


class MeloTts(Tts):
    """Local MeloTTS, driven as a subprocess by an interpreter that has it."""

    def __init__(self, python: str, language: str, settings: dict) -> None:
        super().__init__("melo")
        self.python = python
        self.language = language
        self.settings = settings
        self.raw_dir: Path | None = None

    @property
    def name(self) -> str:
        return (
            f"melo ({self.language}, speaker {self.settings['speaker']}, "
            f"speed {float(self.settings['speed']):g})"
        )

    def intermediate_path(self, out_wav: Path) -> Path:
        # Never point this at out_wav: `render` hands it to ffmpeg as the input,
        # so it must be a different file.
        base = self.raw_dir if self.raw_dir is not None else out_wav.parent
        return base / out_wav.name

    def prepare(self, items: list[tuple[str, str]], work: Path, voice: str, rate: int) -> None:
        self.raw_dir = work / "_melo_raw"
        if self.raw_dir.exists():
            shutil.rmtree(self.raw_dir)
        self.raw_dir.mkdir(parents=True, exist_ok=True)
        spec = {
            "language": self.language,
            **self.settings,
            "jobs": [
                {"id": line_id, "text": text, "out": str(self.raw_dir / f"{line_id}.wav")}
                for line_id, text in items
            ],
        }
        job_file = work / "melo_jobs.json"
        job_file.write_text(json.dumps(spec, ensure_ascii=False), encoding="utf-8")
        print(
            f"  melo: 预合成 {len(spec['jobs'])} 条（{self.name}）-> {self.raw_dir}"
        )
        res = run([self.python, str(MELO_WORKER), "--jobs", str(job_file)])
        if res.returncode != 0:
            detail = (res.stderr or res.stdout or "").strip()[-1200:]
            raise RuntimeError(f"MeloTTS failed (exit {res.returncode}): {detail}")
        missing = [
            line_id
            for line_id, _ in items
            if not (self.raw_dir / f"{line_id}.wav").exists()
            or (self.raw_dir / f"{line_id}.wav").stat().st_size == 0
        ]
        if missing:
            raise RuntimeError(f"MeloTTS 没有产出这些行：{', '.join(missing[:6])}")

    def synthesize(self, text: str, intermediate: Path, voice: str, rate: int) -> None:
        # prepare() already synthesised every clip in one model-load pass.
        if not intermediate.exists():
            raise RuntimeError(f"MeloTTS 未产出 {intermediate}")


class EdgeTts(Tts):
    """edge-tts（微软在线 TTS）。韵律稳、中文自然，但合成时要联网。"""

    def __init__(self, python: str, voice_name: str, settings: dict) -> None:
        super().__init__("edge")
        self.python = python
        self.voice_name = voice_name
        self.settings = settings
        self.raw_dir: Path | None = None

    @property
    def name(self) -> str:
        return f"edge ({self.voice_name})"

    def intermediate_path(self, out_wav: Path) -> Path:
        base = self.raw_dir if self.raw_dir is not None else out_wav.parent
        return base / out_wav.name

    def prepare(self, items: list[tuple[str, str]], work: Path, voice: str, rate: int) -> None:
        self.raw_dir = work / "_edge_raw"
        if self.raw_dir.exists():
            shutil.rmtree(self.raw_dir)
        self.raw_dir.mkdir(parents=True, exist_ok=True)
        spec = {
            "voice": self.voice_name,
            **self.settings,
            "jobs": [
                {"id": line_id, "text": text, "out": str(self.raw_dir / f"{line_id}.wav")}
                for line_id, text in items
            ],
        }
        job_file = work / "edge_jobs.json"
        job_file.write_text(json.dumps(spec, ensure_ascii=False), encoding="utf-8")
        print(f"  edge: 预合成 {len(spec['jobs'])} 条（{self.name}）-> {self.raw_dir}")
        res = run([self.python, str(EDGE_WORKER), "--jobs", str(job_file)])
        if res.returncode != 0:
            detail = (res.stderr or res.stdout or "").strip()[-1200:]
            raise RuntimeError(f"edge-tts failed (exit {res.returncode}): {detail}")
        missing = [
            line_id
            for line_id, _ in items
            if not (self.raw_dir / f"{line_id}.wav").exists()
            or (self.raw_dir / f"{line_id}.wav").stat().st_size == 0
        ]
        if missing:
            raise RuntimeError(f"edge-tts 没有产出这些行：{', '.join(missing[:6])}")

    def synthesize(self, text: str, intermediate: Path, voice: str, rate: int) -> None:
        # prepare() 已经一次性合成完了
        if not intermediate.exists():
            raise RuntimeError(f"edge-tts 未产出 {intermediate}")


def _fallback_tts() -> Tts | None:
    """MeloTTS 装上了却跑挂时的退路：espeak-ng → espeak → macOS say。"""
    for backend in ("espeak-ng", "espeak", "say"):
        if shutil.which(backend) is None:
            continue
        if backend in ("espeak-ng", "espeak"):
            for candidate in ESPEAK_VOICE_CANDIDATES:
                if run([backend, "-v", candidate, "-w", os.devnull, "test"]).returncode == 0:
                    return EspeakTts(backend, candidate)
            # an English-accented reading beats no narration at all
            if run([backend, "-v", "en", "-w", os.devnull, "test"]).returncode == 0:
                return EspeakTts(backend, "en")
            continue
        return SayTts()
    return None


def _build_backend(backend: str, voice: str) -> Tts | None:
    """按名字造一个后端实例；该后端不可用则返回 None。"""
    if backend == "edge":
        python = find_edge_python()
        return EdgeTts(python, _edge_voice(voice), _edge_settings()) if python else None
    if backend == "melo":
        python = find_melo_python()
        return MeloTts(python, _melo_language(voice), _melo_settings()) if python else None
    if backend == "say":
        return SayTts() if shutil.which("say") else None
    if backend in ("espeak-ng", "espeak"):
        if shutil.which(backend) is None:
            return None
        for candidate in ESPEAK_VOICE_CANDIDATES:
            if run([backend, "-v", candidate, "-w", os.devnull, "test"]).returncode == 0:
                return EspeakTts(backend, candidate)
        # an English-accented reading beats no narration at all
        if run([backend, "-v", "en", "-w", os.devnull, "test"]).returncode == 0:
            return EspeakTts(backend, "en")
        return None
    return None


def _fallback_tts(exclude: set[str], voice: str = "auto") -> Tts | None:
    """按候选顺序找下一个能用的后端，跳过已经失败过的那些。"""
    for backend in _tts_candidates("auto"):
        if backend in exclude:
            continue
        candidate = _build_backend(backend, voice)
        if candidate is not None:
            return candidate
    return None


def detect_tts(preferred: str, voice: str = "auto") -> Tts | None:
    for backend in _tts_candidates(preferred):
        candidate = _build_backend(backend, voice)
        if candidate is not None:
            return candidate
    return None


def silent_clip(text: str, out_wav: Path) -> None:
    """Subtitles-only fallback: silence as long as the line would be spoken."""
    seconds = min(max(0.8, han_len(text) / CHARS_PER_SECOND), MAX_CLIP_SECONDS)
    res = run([
        "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
        "-f", "lavfi", "-i", f"anullsrc=r={RATE}:cl=mono",
        "-t", f"{seconds:.3f}", "-c:a", "pcm_s16le", str(out_wav),
    ])
    if res.returncode != 0:
        raise RuntimeError(f"ffmpeg failed generating silence: {res.stderr.strip()}")


def make_silence(path: Path, seconds: float) -> None:
    """A short silent wav used as the breath between scenes."""
    res = run([
        "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
        "-f", "lavfi", "-i", f"anullsrc=r={RATE}:cl=mono",
        "-t", f"{seconds:.3f}", "-c:a", "pcm_s16le", str(path),
    ])
    if res.returncode != 0:
        raise RuntimeError(f"ffmpeg failed generating silence: {res.stderr.strip()}")


# Characters that already end a clause / sentence; joining two lines should not
# add another separator when the first one has one.
_CLOSERS = "，。！？；：、…,.!?;:"
_STRONG_END = "。！？…!?"


def join_texts(texts: list[str]) -> str:
    """Join a scene's subtitle lines into one continuous TTS utterance.

    Internal `。` becomes `，` so the voice keeps moving through the scene; only
    the last line keeps its final stop. This is what removes the "one sentence
    per line" cadence without touching the subtitles themselves.
    """
    out = ""
    for text in texts:
        t = text.strip()
        if not t:
            continue
        if out:
            if out[-1] == "。":
                out = out[:-1] + "，"
            elif out[-1] not in _CLOSERS:
                out += "，"
        out += t
    if out and out[-1] not in _STRONG_END:
        out += "。"
    return out


def trim_silence(src: Path, dst: Path) -> None:
    """Trim TTS lead/tail padding, keeping a short natural margin.

    The model adds a few hundred milliseconds of silence to every clip. Combined
    with our own gap it reads as a hard stop between lines, so the pauses in the
    final track are ours: 50ms lead + 80ms tail, then the scene gap.
    """
    af = (
        "silenceremove=start_periods=1:start_silence=0.05:start_threshold=-45dB,"
        "areverse,"
        "silenceremove=start_periods=1:start_silence=0.08:start_threshold=-45dB,"
        "areverse"
    )
    res = run([
        "ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-i", str(src),
        "-af", af, "-ar", str(RATE), "-ac", "1", "-c:a", "pcm_s16le", str(dst),
    ])
    if res.returncode != 0 or probe_duration_ms(dst) < 200:
        shutil.copyfile(src, dst)


def line_boundaries(
    unit_wav: Path,
    duration_ms: float,
    lines: list[dict],
    measured_ms: list[float] | None = None,
    detect_silence: bool = True,
) -> list[float]:
    """Approximate where each subtitle line starts inside one scene clip.

    A boundary is either a real pause in the TTS (a `。` between lines) or the
    point where the line's measured speech duration is reached. `measured_ms`
    comes from synthesising each line separately (discarded audio) — it is much
    closer than a character-count guess, while the scene itself stays one
    continuous take.
    """
    if len(lines) <= 1:
        return [0.0, duration_ms]

    if measured_ms and len(measured_ms) == len(lines) - 1 and sum(measured_ms) > 0:
        measured = [max(1.0, float(value)) for value in measured_ms]
        # The last line has no separate measurement; give it the leftover of the
        # scene so the weights add up to the group duration.
        weights = measured + [max(1.0, duration_ms - sum(measured))]
    else:
        weights = [
            float(
                max(1, int(line["chars"]))
                + (2 if line["text"].rstrip() and line["text"].rstrip()[-1] in "。！？" else 0)
            )
            for line in lines
        ]
    total = float(sum(weights))
    internal: list[tuple[float, float]] = []
    if detect_silence:
        internal = [
            (start, end)
            for start, end in silence_segments(unit_wav)
            if start > 90 and end < duration_ms - 90 and (end - start) >= 90
        ]

    bounds = [0.0]
    acc = 0.0
    for i in range(1, len(lines)):
        acc += weights[i - 1]
        estimate = duration_ms * acc / total
        best = min(
            internal,
            key=lambda seg: abs((seg[0] + seg[1]) / 2.0 - estimate),
            default=None,
        )
        if best is not None and abs((best[0] + best[1]) / 2.0 - estimate) <= max(
            800.0, duration_ms * 0.22
        ):
            onset = best[1]
        else:
            onset = estimate
        # Keep the boundary strictly inside the clip and after the previous one.
        onset = max(onset, bounds[-1] + 150.0)
        onset = min(onset, duration_ms - 120.0 * (len(lines) - i))
        bounds.append(round(onset, 2))
    bounds.append(duration_ms)
    return bounds


# --------------------------------------------------------------------------
# Dry run
# --------------------------------------------------------------------------


def dry_run_report(script: Script) -> int:
    scene_pause = SCENE_PAUSE_MS / 1000.0
    total = 0.0
    problems: list[str] = []

    print(f"{script.id}: dry run @ {CHARS_PER_SECOND} chars/s, rate={script.rate}")
    print(f"  canvas {script.width}x{script.height} @ {script.fps}fps, style={script.style}")
    print("")
    for scene in script.scenes:
        chars = 0
        lines = scene["lines"]
        for _, text in lines:
            chars += han_len(text)
        # 每个场景是一段连续语音；只有场与场之间留一口气，行与行之间不额外停顿。
        seconds = chars / CHARS_PER_SECOND + scene_pause + 0.05 * max(0, len(lines) - 1)
        total += seconds
        flag = ""
        if seconds > SCENE_MAX_SECONDS:
            flag = "  <-- too long"
            problems.append(f"{scene['id']} {scene['visual']}: {seconds:.1f}s")
        print(
            f"  {scene['id']} {scene['visual']:<13} {seconds:5.1f}s  {chars:>3} chars "
            f"{'#' * max(1, round(seconds * 2))}{flag}"
        )

    total += FINAL_TAIL_MS / 1000.0
    print("")
    print(f"  scenes={len(script.scenes)} lines={len(script.flat)} "
          f"chars={sum(han_len(t) for _, _, _, t in script.flat)}")
    print(f"  estimated total: {total:.1f}s")
    if total > TOTAL_MAX_SECONDS:
        print(f"  !! over budget by {total - TOTAL_MAX_SECONDS:.1f}s", file=sys.stderr)
        problems.append(f"total {total:.1f}s")
    for p in problems:
        print(f"  !! {p}", file=sys.stderr)
    return 1 if problems else 0


# --------------------------------------------------------------------------
# Build
# --------------------------------------------------------------------------


def build(script: Script, force_no_audio: bool, preferred_tts: str) -> int:
    fps = script.fps
    work = OUT / f"_tts_{script.id}"
    if work.exists():
        shutil.rmtree(work)
    work.mkdir(parents=True, exist_ok=True)
    PUBLIC.mkdir(parents=True, exist_ok=True)
    script.timing_ts.parent.mkdir(parents=True, exist_ok=True)
    (PROJECT / script.out_file).parent.mkdir(parents=True, exist_ok=True)
    script.lrc.parent.mkdir(parents=True, exist_ok=True)

    scene_pause_frames = round(SCENE_PAUSE_MS / 1000.0 * fps)

    # ---- 0. one continuous utterance per scene ------------------------
    #
    # 台词按「场景」合成，而不是按字幕行逐行合成。逐行合成会让每一行都重新起调、
    # 收调，再叠上模型尾部的静音和我们的行间停顿，成片就是一顿一顿的「蹦字」。
    # 场景内多行先用 join_texts 连成一句话（内部句号变逗号），字幕行仍然保留，
    # 时间轴再按字数比例 / 句间静音把每一行放回这句话里。
    units: list[dict] = []
    for scene in script.scenes:
        scene_lines = [
            {"id": line_id, "text": text, "chars": han_len(text)}
            for line_id, text in scene["lines"]
        ]
        units.append(
            {
                "id": scene["id"],
                "sceneId": scene["id"],
                "visual": scene["visual"],
                "lines": scene_lines,
                "text": join_texts([line["text"] for line in scene_lines]),
            }
        )

    # 只有多行场景需要「测量行」：单独合成每一行（音频随后丢弃），用它的
    # 真实时长把字幕行放回场景里。单行场景不需要，边界就是 0..整段。
    measure_lines = [
        line
        for unit in units
        if len(unit["lines"]) > 1
        for line in unit["lines"][:-1]
    ]

    tts = None if force_no_audio else detect_tts(preferred_tts, script.voice)
    failed_backends: set[str] = set()
    while tts is not None:
        print(f"{script.id}: TTS = {tts.name}")
        try:
            # 批量型后端（edge-tts / MeloTTS）一次性把每个场景合成好；
            # say / espeak 的这个钩子是空的，仍然逐场景合成。
            tts.prepare(
                [(unit["id"], unit["text"]) for unit in units]
                + [(line["id"], line["text"]) for line in measure_lines],
                work,
                script.voice,
                script.rate,
            )
            break
        except RuntimeError as error:
            # 换下一个后端继续尝试（edge-tts 没网 → MeloTTS 本地 → espeak），
            # 全部失败才退化成纯字幕版。
            print(f"warning: {tts.name} 不可用：{error}", file=sys.stderr)
            failed_backends.add(tts.backend)
            tts = _fallback_tts(failed_backends, script.voice)
            if tts is not None:
                print(f"{script.id}: 改用 {tts.name}（回退）", file=sys.stderr)
    if tts is None:
        print(
            f"{script.id}: no TTS available -> generating silent clips; "
            "the video will run as subtitles-only",
            file=sys.stderr,
        )

    print(
        f"{script.id}: scenes={len(script.scenes)} units={len(units)} "
        f"lines={len(script.flat)} weight={sum(han_len(t) for _, _, _, t in script.flat)}"
    )

    # ---- 1. synthesise / trim one clip per scene ----------------------
    clips: list[dict] = []
    concat_entries: list[Path] = []
    unit_start_ms = 0.0
    gap_wav = work / "_scene_gap.wav"
    if len(units) > 1:
        make_silence(gap_wav, SCENE_PAUSE_MS / 1000.0)

    for unit_index, unit in enumerate(units):
        raw = work / f"{unit['id']}.wav"
        if tts is not None:
            tts.render(unit["text"], raw, script.voice, script.rate)
            wav = work / f"{unit['id']}.trim.wav"
            trim_silence(raw, wav)
        else:
            silent_clip(unit["text"], raw)
            wav = raw

        duration_ms = probe_duration_ms(wav)

        # 多行场景：逐行测量时长，字幕边界按真实行时长分配，而不是按字数猜。
        measured_ms: list[float] = []
        if tts is not None and len(unit["lines"]) > 1:
            for line in unit["lines"][:-1]:
                line_raw = work / f"{line['id']}.wav"
                tts.render(line["text"], line_raw, script.voice, script.rate)
                line_trim = work / f"{line['id']}.trim.wav"
                trim_silence(line_raw, line_trim)
                measured_ms.append(probe_duration_ms(line_trim))

        bounds = line_boundaries(
            wav,
            duration_ms,
            unit["lines"],
            measured_ms,
            detect_silence=tts is not None,
        )

        for line_index, line in enumerate(unit["lines"]):
            start_rel = bounds[line_index]
            end_rel = bounds[line_index + 1]
            gap_frames = (
                scene_pause_frames if line_index == len(unit["lines"]) - 1 else 0
            )
            clip = {
                "sceneId": unit["sceneId"],
                "visual": unit["visual"],
                "id": line["id"],
                "text": line["text"],
                "path": wav,
                "durationMs": round(end_rel - start_rel, 2),
                "onsetMs": round(unit_start_ms + start_rel, 2),
                "gapFrames": gap_frames,
                "gapMs": round(gap_frames / fps * 1000.0, 2),
                "chars": line["chars"],
                "unitId": unit["id"],
                "unitDurationMs": round(duration_ms, 2),
            }
            clips.append(clip)
            print(
                f"  {line['id']}  +{clip['onsetMs']/1000:7.2f}s  "
                f"{clip['durationMs']/1000:5.2f}s  {unit['id']}  {line['text'][:24]}"
            )

        concat_entries.append(wav)
        unit_start_ms += duration_ms
        if unit_index + 1 < len(units):
            concat_entries.append(gap_wav)
            unit_start_ms += SCENE_PAUSE_MS

    # ---- 2. assemble the continuous narration track -------------------
    concat_list = work / "concat.txt"
    concat_list.write_text(
        "".join(f"file '{path.resolve().as_posix()}'\n" for path in concat_entries),
        encoding="utf-8",
    )

    tail_frames = round(FINAL_TAIL_MS / 1000.0 * fps)
    track = PUBLIC / script.audio_track
    has_audio = tts is not None
    afilter = f"apad=pad_dur={tail_frames / fps:.3f}"
    if has_audio:
        afilter = (
            "highpass=f=90,"
            "acompressor=threshold=-18dB:ratio=3:attack=7:release=160,"
            "loudnorm=I=-16:TP=-1.5:LRA=11," + afilter
        )
    res = run([
        "ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
        "-f", "concat", "-safe", "0", "-i", str(concat_list),
        "-af", afilter, "-ar", str(RATE), "-ac", "1",
        "-c:a", "pcm_s16le", str(track),
    ])
    if res.returncode != 0:
        print(f"error: concat failed: {res.stderr}", file=sys.stderr)
        return 1

    track_ms = probe_duration_ms(track)

    # ---- 3. snap the timeline onto the frame grid ---------------------
    #
    # Onsets are known from the assembled unit durations and the in-unit line
    # boundaries; snapping happens once and never accumulates, so rounding
    # error cannot compound. A line only moves if its snapped onset would
    # collide with the previous line. Line ends come from the *next* onset,
    # which keeps every line inside the audio instead of stretching the video
    # past the end of the voice track.
    total_frames = max(int(round(track_ms / 1000.0 * fps)), len(clips))

    prev_frame = -1
    for i, clip in enumerate(clips):
        f = int(round(clip["onsetMs"] / 1000.0 * fps))
        if i > 0:
            f = max(f, prev_frame + 1)
        clip["startFrame"] = f
        prev_frame = f

    for i, clip in enumerate(clips):
        onset_frame = clip["startFrame"]
        end_frame = clips[i + 1]["startFrame"] - 2 if i + 1 < len(clips) else total_frames
        end_frame = max(onset_frame + 1, min(end_frame, total_frames))

        clip["index"] = i
        clip["endFrame"] = end_frame
        clip["startMs"] = round(onset_frame / fps * 1000.0, 2)
        clip["endMs"] = round(end_frame / fps * 1000.0, 2)
        clip["speechFrames"] = end_frame - onset_frame
        clip["speechMs"] = round(clip["speechFrames"] / fps * 1000.0, 2)
        clip["totalFrames"] = clip["speechFrames"] + clip["gapFrames"]
        clip["totalMs"] = round(clip["totalFrames"] / fps * 1000.0, 2)

    total_ms = total_frames / fps * 1000.0

    # ---- 4. scene timings --------------------------------------------
    scenes: list[dict] = []
    for scene in script.scenes:
        own = [c for c in clips if c["sceneId"] == scene["id"]]
        if not own:
            continue
        scenes.append(
            {
                "id": scene["id"],
                "visual": scene["visual"],
                "index": len(scenes),
                "lineIds": [c["id"] for c in own],
                "firstLineIndex": own[0]["index"],
                "lastLineIndex": own[-1]["index"],
                "rawStartFrame": max(
                    0, own[0]["startFrame"] - (SCENE_LEAD_FRAMES if scenes else 0)
                ),
                "lineStartFrame": own[0]["startFrame"],
                "speechFrames": sum(c["speechFrames"] for c in own),
                "chars": sum(c["chars"] for c in own),
            }
        )

    starts: list[int] = []
    for scene in scenes:
        start = scene.pop("rawStartFrame")
        if starts:
            start = max(start, starts[-1] + 1)
        starts.append(start)

    for i, scene in enumerate(scenes):
        end = starts[i + 1] if i + 1 < len(scenes) else total_frames
        scene["startFrame"] = starts[i]
        scene["endFrame"] = end
        scene["durationInFrames"] = max(1, end - starts[i])
        scene["durationSeconds"] = round(scene["durationInFrames"] / fps, 2)
        scene["startMs"] = round(starts[i] / fps * 1000.0, 2)
        scene["lineStartMs"] = round(scene["lineStartFrame"] / fps * 1000.0, 2)

    # ---- 5. guard rails ----------------------------------------------
    problems: list[str] = []
    for scene in scenes:
        if scene["durationSeconds"] > SCENE_MAX_SECONDS:
            problems.append(
                f"{scene['id']} ({scene['visual']}) runs {scene['durationSeconds']}s "
                f"~ {scene['chars']} chars — trim it or split the scene"
            )
    if total_ms / 1000.0 > TOTAL_MAX_SECONDS:
        problems.append(
            f"total runtime {total_ms/1000:.1f}s exceeds the {TOTAL_MAX_SECONDS:.0f}s budget"
        )

    # ---- 6. outputs ---------------------------------------------------
    #
    # The generated TypeScript carries only what the composition reads at
    # render time. The full record (clip durations, measured onsets, char
    # counts) goes to JSON next to the other build artifacts.
    config_ts = (
        "/* GENERATED by scripts/build_audio.py — do not edit by hand. */\n\n"
        "export type VideoConfig = {\n"
        "  id: string;\n"
        "  fps: number;\n"
        "  width: number;\n"
        "  height: number;\n"
        "  audioTrack: string;\n"
        "  outFile: string;\n"
        '  style: "whiteboard";\n'
        "  voice: string;\n"
        "  rate: number;\n"
        "  hasAudio: boolean;\n"
        "};\n\n"
        "export const VIDEO: VideoConfig = "
        + json.dumps(
            {
                "id": script.id,
                "fps": fps,
                "width": script.width,
                "height": script.height,
                "audioTrack": script.audio_track,
                "outFile": script.out_file,
                "style": script.style,
                "voice": script.voice,
                "rate": script.rate,
                "hasAudio": has_audio,
            },
            ensure_ascii=False,
            indent=2,
        )
        + ";\n"
    )
    script.config_ts.write_text(config_ts, encoding="utf-8")

    public_lines = [
        {
            "id": c["id"],
            "index": c["index"],
            "sceneId": c["sceneId"],
            "text": c["text"],
            "startFrame": c["startFrame"],
            "endFrame": c["endFrame"],
        }
        for c in clips
    ]
    timing = {
        "fps": fps,
        "width": script.width,
        "height": script.height,
        "durationInFrames": total_frames,
        "audioTrack": script.audio_track,
        "lines": public_lines,
        "scenes": [
            {
                "id": s["id"],
                "visual": s["visual"],
                "index": s["index"],
                "lineIds": s["lineIds"],
                "startFrame": s["startFrame"],
                "endFrame": s["endFrame"],
                "durationInFrames": s["durationInFrames"],
            }
            for s in scenes
        ],
    }
    script.timing_ts.write_text(
        "/* GENERATED by scripts/build_audio.py — do not edit by hand. */\n"
        'import type { Timing } from "../whiteboard/types";\n\n'
        "export const TIMING: Timing = "
        + json.dumps(timing, ensure_ascii=False, indent=2)
        + ";\n",
        encoding="utf-8",
    )

    (OUT / f"{script.id}-timing.json").write_text(
        json.dumps(
            {
                "id": script.id,
                "title": script.title,
                "fps": fps,
                "width": script.width,
                "height": script.height,
                "durationInFrames": total_frames,
                "durationMs": round(total_ms, 2),
                "audioTrackMs": round(track_ms, 2),
                "speechMs": round(sum(c["speechMs"] for c in clips), 2),
                "voice": script.voice,
                "rate": script.rate,
                "tts": tts.name if tts else "none (silent)",
                "hasAudio": has_audio,
                "style": script.style,
                "outFile": script.out_file,
                "lines": [{k: v for k, v in c.items() if k != "path"} for c in clips],
                "scenes": scenes,
            },
            ensure_ascii=False,
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    def stamp(ms: float) -> str:
        cs = int(round(ms / 10.0))
        return f"[{cs // 6000:02d}:{cs // 100 % 60:02d}.{cs % 100:02d}]"

    lrc = [
        f"[ti:{script.title}]",
        "[ar:讲解动画]",
        f"[al:{script.audio_track}]",
        "[by:sketch explainer]",
        f"[length:{int(total_ms // 60000):02d}:{int(total_ms // 1000) % 60:02d}]",
        "",
    ]
    for clip in clips:
        lrc.append(f"{stamp(clip['startMs'])}{clip['text']}")
    script.lrc.write_text("\n".join(lrc) + "\n", encoding="utf-8")

    sheet = [
        f"# 分镜台词时间轴 / cue sheet — {script.id}",
        "",
        f"- 标题: {script.title}",
        f"- 画幅: {script.width}x{script.height} @ {fps}fps（style: {script.style}）",
        f"- 总时长: {total_ms/1000:.2f}s ({total_frames} frames)",
        f"- 音轨实测时长: {track_ms/1000:.2f}s",
        f"- 纯语音时长: {sum(c['speechMs'] for c in clips)/1000:.2f}s",
        f"- 场景数: {len(scenes)} / 台词行数: {len(clips)}",
        f"- 配音: {tts.name if tts else '无（纯字幕）'}",
        f"- 入点来源: 按场景实测时长 + 组内静音/字数比例分配",
        f"- 合成单位: 每场 1 条连续语音（行间不停顿）",
        "",
        "| # | 场景 | 台词 | LRC 入点 | 语音 | 画面帧 |",
        "|---|---|---|---|---|---|",
    ]
    scene_of = {s["id"]: s for s in scenes}
    for clip in clips:
        scene = scene_of[clip["sceneId"]]
        sheet.append(
            f"| {clip['index']+1} | {scene['id']} {scene['visual']} | {clip['text']} "
            f"| {stamp(clip['startMs'])} | {clip['speechMs']/1000:.2f}s "
            f"| {scene['startFrame']}–{scene['endFrame']} |"
        )
    script.cue_sheet.write_text("\n".join(sheet) + "\n", encoding="utf-8")

    # ---- 7. report ----------------------------------------------------
    print("")
    for scene in scenes:
        bar = "#" * max(1, round(scene["durationSeconds"] * 2))
        print(
            f"  {scene['id']} {scene['visual']:<13} {scene['durationSeconds']:5.1f}s "
            f"f{scene['startFrame']:>5}-{scene['endFrame']:<5} {bar}"
        )
    worst = max(abs(c["startMs"] - c["onsetMs"]) for c in clips)
    print("")
    print(f"max |网格入点 - 语音入点|: {worst:.1f}ms")
    print(f"track     -> {track}  ({track_ms/1000:.2f}s)")
    print(f"timing    -> {script.timing_ts}  ({total_frames} frames, {len(scenes)} scenes)")
    print(f"config    -> {script.config_ts}")
    print(f"lrc       -> {script.lrc}  ({len(clips)} cues)")
    print(f"cue sheet -> {script.cue_sheet}")
    print(f"TOTAL     -> {total_ms/1000:.2f}s")

    if problems:
        print("", file=sys.stderr)
        print("!! pacing guard rails:", file=sys.stderr)
        for p in problems:
            print(f"   - {p}", file=sys.stderr)
        return 1
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--script", default=str(PROJECT / "scripts" / "script.json"))
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--no-audio", action="store_true",
                    help="skip TTS entirely and generate silent clips")
    ap.add_argument("--tts", default="auto",
                    help="auto | edge | melo | say | espeak-ng | espeak")
    args = ap.parse_args()

    script = Script(Path(args.script))

    if args.dry_run:
        return dry_run_report(script)

    for tool in ("ffmpeg", "ffprobe"):
        if shutil.which(tool) is None:
            print(f"error: {tool} not found on PATH", file=sys.stderr)
            return 1

    return build(script, args.no_audio, args.tts)


if __name__ == "__main__":
    raise SystemExit(main())
